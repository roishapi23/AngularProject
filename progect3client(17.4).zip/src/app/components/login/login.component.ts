import { CartsService } from 'src/app/services/carts.service';
import { UsersService } from './../../services/users.service';
import { UserLoginDetails } from '../../models/UserLoginDetails';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public userLoginDetails: UserLoginDetails
  activatedRoute: ActivatedRoute;

  constructor(public usersService: UsersService, public cartsService:CartsService ,  private router:Router , private route: ActivatedRoute) {
    this.userLoginDetails = new UserLoginDetails();
    this.usersService = usersService;
    this.cartsService = cartsService;

   }

  ngOnInit() {
    sessionStorage.clear();
    this.initCartsService();
  }

  public login(){
    console.log(this.userLoginDetails)

    let observable = this.usersService.login(this.userLoginDetails);

    observable.subscribe(successFullLoginResponse => {
      console.log(successFullLoginResponse);
      sessionStorage.setItem("userName", JSON.stringify(successFullLoginResponse.name))
      sessionStorage.setItem("token", successFullLoginResponse.token);
      this.usersService.customerName = successFullLoginResponse.name;
      this.usersService.userType = successFullLoginResponse.userType;
      this.usersService.userId = successFullLoginResponse.id;
      console.log("user id is : "+this.usersService.userId);
      this.usersService.isUserLoggedIn = true;
      if (this.usersService.userType == "ADMIN") {
      this.router.navigate(['admin'], {relativeTo: this.activatedRoute})
      return;
      }
      this.router.navigate(['home/customer'], {relativeTo: this.activatedRoute})

    },error =>{
      alert("faild to connect")
    })
    
  }

  public routeToRegister(){
    // this.router.navigate(["register"])
    // this.router.navigate(['/list'], {relativeTo: this.route});
    this.router.navigate(['home/register'], {relativeTo: this.activatedRoute})
  }

  public initCartsService(){
    this.cartsService.userHasOldCart = false;
    this.cartsService.userHasOpenCart = false;
  }

}
