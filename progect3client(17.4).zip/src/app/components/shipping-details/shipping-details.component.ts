import { PurchasesService } from './../../services/purchases.service';
import { ShippingDetails } from './../../models/ShippingDetails';
import { Component, OnInit } from '@angular/core';
import { CartsService } from 'src/app/services/carts.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-shipping-details',
  templateUrl: './shipping-details.component.html',
  styleUrls: ['./shipping-details.component.css']
})
export class ShippingDetailsComponent implements OnInit {
  public customerShippingDetails: ShippingDetails;
  public userDetails:Object;
  public isDateAvailable = true;
  public purchaseCompleted = false;
  public resarvationNumber = 0;
  activatedRoute: ActivatedRoute;

  constructor(public purchaseService:PurchasesService , public cartsService:CartsService , private router:Router , private route: ActivatedRoute) {
    this.customerShippingDetails = new ShippingDetails();
   }

  ngOnInit() {
    this.customerShippingDetails.cartId = this.cartsService.userCartId;
    
  }

  public pay(){
    this.isDateAvailable = true;
    console.log(this.customerShippingDetails);
    let observable = this.purchaseService.setThePurchase(this.customerShippingDetails)
    observable.subscribe(purchaseResponse =>{
      console.log(purchaseResponse)
      if (purchaseResponse.dateAvilabilityStatus == false) {
        this.isDateAvailable = false;
        return;
      }
      this.purchaseCompleted = true;
      this.resarvationNumber = purchaseResponse.resarvationNumber
      
      

    }, error => {
      // some error action
    })
  }
  public fillDetails(){
    // let userDetails = JSON.parse(sessionStorage.getItem("userDetails"));
    let observable = this.purchaseService.getCustomerShippingAddress();
    observable.subscribe(customerAddress =>{
      
      console.log(customerAddress.city)
      console.log(customerAddress.street)
      this.customerShippingDetails.city = customerAddress.city;
      this.customerShippingDetails.street = customerAddress.street;

    }, error => {
      // some error action
    })
  }

  public navToHomePage(){
    sessionStorage.setItem("Cart ID", JSON.stringify(0));
    this.cartsService.cartItemsList = [];
    this.cartsService.cartTotalPrice = 0;
    this.router.navigate(['home/customer'], {relativeTo: this.activatedRoute})
  }

}
