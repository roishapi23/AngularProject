import { Component, OnInit } from '@angular/core';
import { CartsService } from 'src/app/services/carts.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-final-cart',
  templateUrl: './final-cart.component.html',
  styleUrls: ['./final-cart.component.css']
})
export class FinalCartComponent implements OnInit {
  public cartItems = [];
  public cartPrice: number;
  public cartId:number;
    activatedRoute: ActivatedRoute;

  constructor(public cartsService:CartsService , private router:Router , private route: ActivatedRoute) { }

  ngOnInit() {
    let cartId = JSON.parse(sessionStorage.getItem("Cart ID")) /* get cartId if exist */
    this.cartsService.userCartId = cartId
    this.cartId = this.cartsService.userCartId;
    if (cartId != undefined) { /* at this point, if cart id exist that means the user has open cart */
      
      let observable = this.cartsService.getCartByCartId(cartId); 
      observable.subscribe(openCart => { /* setting a request to get user cart */
        // console.log(openCart)
        /* setting the cart into var in the service so it will be accsessable to other components */
        this.cartsService.cartItemsList = openCart.cart; 
        /* setting the cart on this component to show it, making it dynamic for changes from other components */
        /* thanks to the fact that his value is from the service */
        this.cartItems = this.cartsService.cartItemsList;
        /* same thing to the cart price */
        this.cartsService.cartTotalPrice = openCart.cartPrice;
        this.cartPrice = this.cartsService.cartTotalPrice;
        // this.cartPrice = openCart.cartPrice;

        // this.cartsService.newCartId = addCartResponse.cartId;
        // console.log(this.cartsService.newCartId)
        
      }, error => {
        // some error action
      })
      /* end of displaying open cart */
      return;
    }
  }

  public backToCart(){
    this.router.navigate(['shop'], {relativeTo: this.activatedRoute})
  }

}
