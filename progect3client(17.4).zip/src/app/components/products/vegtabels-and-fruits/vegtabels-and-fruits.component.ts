import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/productDetails';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-vegtabels-and-fruits',
  templateUrl: './vegtabels-and-fruits.component.html',
  styleUrls: ['./vegtabels-and-fruits.component.css']
})
export class VegtabelsAndFruitsComponent implements OnInit {

  public products : Product[];
  private categoryId : Number;

  constructor(private productsService : ProductsService) {
    this.categoryId = 3;
   }

  ngOnInit() {
    let observable = this.productsService.getProductsbyCategory(this.categoryId);
    observable.subscribe(vegtabelsAndFruits =>{
      console.log(vegtabelsAndFruits)
      this.products = vegtabelsAndFruits;
      
    },error =>{

    })
  }


}
