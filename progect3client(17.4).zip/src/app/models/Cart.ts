export class Cart {
    constructor(
        public cart:[],
        public cartPrice:number
        
    ){}
}