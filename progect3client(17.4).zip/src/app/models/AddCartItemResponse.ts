export class AddCartItemResponse {
    constructor(
        public cartItemUpdatedPrice:number,
        public cartUpdatedPrice:number
    ){}
}