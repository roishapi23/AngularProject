export class AmountStatusFirstUI {
    constructor(
        public products?:Number,
        public purchases?:Number
    ){}
}