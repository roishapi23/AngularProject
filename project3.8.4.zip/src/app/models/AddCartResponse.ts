export class AddCartResponse {
    constructor(
        public cartId?:Number
    ){}
}