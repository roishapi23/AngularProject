import { UsersService } from './../../services/users.service';
import { Component, OnInit } from '@angular/core';
import { CartsService } from 'src/app/services/carts.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public cartItems = [];
  public cartPrice = 0;

  constructor(public cartsService:CartsService , public usersService:UsersService) {
    this.cartItems = this.cartsService.cartItemsList;
    // this.cartPrice = this.cartsService.cartTotalPrice;
    this.cartsService = cartsService;
   }

  ngOnInit() {
    // this.cartItems = [
    //   {name: "yossi", amount: 5 , price: 54},
    //   {name: "danielii", amount: 1 , price: 97}
    // ]
    let cartId = JSON.parse(sessionStorage.getItem("Cart ID")) /* get cartId if exist */
    if (cartId != undefined) { /* at this point, if cart id exist that means the user has open cart */
      
      let observable = this.cartsService.getCartByCartId(cartId); 
      observable.subscribe(openCart => { /* setting a request to get user cart */
        console.log(openCart)
        /* setting the cart into var in the service so it will be accsessable to other components */
        this.cartsService.cartItemsList = openCart.cart; 
        /* setting the cart on this component to show it, making it dynamic for changes from other components */
        /* thanks to the fact that his value is from the service */
        this.cartItems = this.cartsService.cartItemsList;
        /* same thing to the cart price */
        this.cartsService.cartTotalPrice = openCart.cartPrice;
        this.cartPrice = this.cartsService.cartTotalPrice;
        // this.cartPrice = openCart.cartPrice;

        // this.cartsService.newCartId = addCartResponse.cartId;
        // console.log(this.cartsService.newCartId)
        
      }, error => {

      })
      /* end of displaying open cart */
      return;
    }
    /* if user doesnt have an open cart - take his id and open him a new cart */
    let userId = this.usersService.userId;
    console.log("id in user service is: "+userId)
    if (userId == undefined) {
      let userDetails = JSON.parse(sessionStorage.getItem("userDetails"))
      userId = userDetails.id
    }
    
    let observable = this.cartsService.setNewCart({id: userId});
    observable.subscribe(addCartResponse => {
      console.log(addCartResponse)
      sessionStorage.setItem("Cart ID" , JSON.stringify(addCartResponse.cartId));
      // this.cartsService.newCartId = addCartResponse.cartId;
      // console.log(this.cartsService.newCartId)
      
    }, error => {

    })
  }

  // public deleteCartItem(){
  //   this.cartItems.splice()
  // }

}
