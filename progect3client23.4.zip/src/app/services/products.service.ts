import { Product } from './../models/productDetails';
import { AmountStatusFirstUI } from './../models/AmountInfoFirstUI';
import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  public userSearchInput : string;

  constructor(private http: HttpClient) { }

  public getProductsbyCategory(id):Observable<Product[]> {
    return this.http.get<Product[]>("/api/products/byCategory/"+id)
  }
  public getFirstUIAmountInfo():Observable<AmountStatusFirstUI> {
    return this.http.get<AmountStatusFirstUI>("/api/products/amount")
  }
  public getAllProducts():Observable<Product[]> {
    return this.http.get<Product[]>("/api/products")
  }
}
