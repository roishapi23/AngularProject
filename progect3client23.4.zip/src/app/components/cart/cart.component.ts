import { UsersService } from './../../services/users.service';
import { Component, OnInit } from '@angular/core';
import { CartsService } from 'src/app/services/carts.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public cartItems = [];
  public cartPrice = 0;
  public cartId:number;
  activatedRoute: ActivatedRoute;

  constructor(public cartsService:CartsService , public usersService:UsersService, private router:Router , private route: ActivatedRoute) {
    this.cartItems = this.cartsService.cartItemsList;
    // this.cartPrice = this.cartsService.cartTotalPrice;
    this.cartsService = cartsService;
   }

  ngOnInit() {

    

    let cartId = JSON.parse(sessionStorage.getItem("Cart ID")) /* get cartId if exist */
    this.cartsService.userCartId = cartId
    this.cartId = this.cartsService.userCartId;
    console.log("current cart id is "+cartId)
    if (cartId != null && cartId != 0) { /* at this point, if cart id exist that means the user has open cart */
      console.log("enterd to bring open cart")
      let observable = this.cartsService.getCartByCartId(cartId); 
      observable.subscribe(openCart => { /* setting a request to get user cart */
        // console.log(openCart)
        /* setting the cart into var in the service so it will be accsessable to other components */
        this.cartsService.cartItemsList = openCart.cart; 
        /* setting the cart on this component to show it, making it dynamic for changes from other components */
        /* thanks to the fact that his value is from the service */
        this.cartItems = this.cartsService.cartItemsList;
        /* same thing to the cart price */
        this.cartsService.cartTotalPrice = openCart.cartPrice;
        this.cartPrice = this.cartsService.cartTotalPrice;
        // this.cartPrice = openCart.cartPrice;

        // this.cartsService.newCartId = addCartResponse.cartId;
        // console.log(this.cartsService.newCartId)
        
      }, error => {
        console.log(error)
        if (error.status == 500) {
        this.router.navigate(['home'], {relativeTo: this.activatedRoute})
        }
        if (error.status == 404) {
        alert(error.error.error)
        }
      })
      /* end of displaying open cart */
      return;
    }

    console.log("open new")
    /* if user doesnt have an open cart - take his id and open him a new cart */
    // let userId = this.usersService.userId;
    // // console.log("id in user service is: "+userId)
    // if (userId == undefined ) {
    //   let userDetails = JSON.parse(sessionStorage.getItem("userDetails"))
    //   userId = userDetails.id
    // }
    
    let observable = this.cartsService.setNewCart();
    observable.subscribe(addCartResponse => {
      // console.log(addCartResponse)
      sessionStorage.setItem("Cart ID" , JSON.stringify(addCartResponse.cartId));
      this.cartsService.userCartId = addCartResponse.cartId;
      this.cartId = this.cartsService.userCartId;
      // console.log(this.cartsService.newCartId)
      
    }, error => {
       console.log(error)
        if (error.status == 500) {
        this.router.navigate(['home'], {relativeTo: this.activatedRoute})
        }
        if (error.status == 404) {
        alert(error.error.error)
        }
    })
  }

  public deleteCartItem(cartItemToDelete){
    console.log(cartItemToDelete)
    this.deleteCartItemFromDB(cartItemToDelete);  
    this.deleteCartItemfromUI(cartItemToDelete);
    
  }
  
  public deleteCartItemfromUI(cartItemToDelete){
    this.cartItems = this.cartsService.cartItemsList
    let currentCartItems = this.cartItems;
    // console.log(cartItemToDelete)
    console.log(currentCartItems)
    // for (let index = 0; index < array.length; index++) {
    //   const element = array[index];
      
    // }
    currentCartItems.map((item,index) =>{
      console.log(index)
      if (item.id == cartItemToDelete.id) {
        // console.log(item.productName);
        // console.log(index);
        currentCartItems.splice(index,1);
        console.log(currentCartItems)
        this.cartsService.cartItemsList = currentCartItems;
        this.cartItems = this.cartsService.cartItemsList;
        return;
      }
    } )
  }
  
  public deleteCartItemFromDB(cartItemToDelete){
    let observable = this.cartsService.deleteCartItem(cartItemToDelete);
    observable.subscribe(afterDeleteServerResponse => {
      // console.log(afterDeleteServerResponse.cartUpdatedPrice);
      let updatedTotalCartPrice = afterDeleteServerResponse.cartUpdatedPrice;
      this.cartsService.cartTotalPrice = updatedTotalCartPrice;
    },error =>{
      /* some error action */
    })
    
  }

  public emptyCart(){
    this.emptyCartFromDB(this.cartId);
    this.emptyCartFromUI()
  }

  public emptyCartFromDB(cartId){
    let observable = this.cartsService.emptyCart(cartId);
    observable.subscribe(afterCartEmptyServerResponse => {
      // console.log(afterDeleteServerResponse.cartUpdatedPrice);
      let updatedTotalCartPrice = afterCartEmptyServerResponse.cartUpdatedPrice;
      this.cartsService.cartTotalPrice = updatedTotalCartPrice;
    },error =>{
      /* some error action */
    })
  }

  public emptyCartFromUI(){
    this.cartsService.cartItemsList = [];
    this.cartItems = this.cartsService.cartItemsList;
  }
  
  public navToPayment(){
    if (this.cartItems.length == 0) {
      alert("your cart is empty")
      return;
    }
    this.router.navigate(['payment'], {relativeTo: this.activatedRoute})
  }

  public back(){
    this.router.navigate(['home/customer'], {relativeTo: this.activatedRoute})
  }
}
