export class ShippingDetails {
    constructor(
        // public customerId?:number,
        public cartId?:number,
        public city?:string,
        public street?:string,
        public dateOfDelivery?:string,
        public creditCard?:number
        
    ){}
}