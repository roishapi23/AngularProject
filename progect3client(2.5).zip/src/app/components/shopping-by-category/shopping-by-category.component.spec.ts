import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShoppingByCategoryComponent } from './shopping-by-category.component';

describe('ShoppingByCategoryComponent', () => {
  let component: ShoppingByCategoryComponent;
  let fixture: ComponentFixture<ShoppingByCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShoppingByCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShoppingByCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
