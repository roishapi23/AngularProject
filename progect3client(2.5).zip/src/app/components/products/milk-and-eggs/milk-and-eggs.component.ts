import { CartsService } from 'src/app/services/carts.service';
import { CartItem } from './../../../models/CartItem';
import { ProductsService } from './../../../services/products.service';
import { Product } from './../../../models/productDetails';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-milk-and-eggs',
  templateUrl: './milk-and-eggs.component.html',
  styleUrls: ['./milk-and-eggs.component.css']
})
export class MilkAndEggsComponent implements OnInit {

  public products : Product[];
  private categoryId : Number;
  public currentClickedProduct: Product; /* pointer to the product the user clicked on */
  public newCartItem : CartItem;

  activatedRoute: ActivatedRoute;

  constructor(private productsService : ProductsService , private cartsService : CartsService, private router:Router , private route: ActivatedRoute) {
    this.categoryId = 2;
    this.currentClickedProduct = {id:0 , productName:"" , price: 0, image:""}; /* init pointer */
    this.newCartItem = new CartItem();
    this.cartsService = cartsService;
  }
  
  ngOnInit() {
    /* get all category products */
    let observable = this.productsService.getProductsbyCategory(this.categoryId);
    observable.subscribe(milkAndEggsProducts =>{
      // console.log(milkAndEggsProducts);
      this.products = milkAndEggsProducts; /* set the server response as our products to display */
      this.currentClickedProduct = milkAndEggsProducts[0]; 
    },error =>{
       console.log(error)
        if (error.status == 500) {
        this.router.navigate(['home'], {relativeTo: this.activatedRoute})
        alert("you can not enter this url, please login for shopping")
        }
        if (error.status == 404) {
        alert(error.error.error)
        }
    })
  }

  public setNewCartItem(productId){
    this.newCartItem.id = productId;
    this.currentClickedProduct.amount = this.newCartItem.amount;
    let cartItem = this.newCartItem
    console.log("current cart item : "+ JSON.stringify(cartItem))
    if(this.checkIfProductExistInCart(cartItem)==true){
      console.log("updating")
      this.updateCartItemAmount(cartItem)
      return
    }
    console.log("adding")
    this.addCartItemToCart(cartItem)
    return;
  }

  
  public setCurrentClickedProduct(clickedProduct){
    this.newCartItem.amount = 1; /* setting information to the object that we will set */
    this.currentClickedProduct = clickedProduct; /* changing the pointer to the product the user clicked on */
    // this.newCartItem.productId = clickedProduct.id; /* setting information to the object that we will set */
  }

  public initProductAmount(){
    this.newCartItem.amount = 1;
  }

  public checkIfProductExistInCart(newCartItem){
    let currentCartItemList = this.cartsService.cartItemsList;
    for (let index = 0; index < currentCartItemList.length; index++) {
      if (currentCartItemList[index].id == newCartItem.id) {
        return true;  
      }
    }
    return false
  }

  public updateCartItemAmount(cartItem){
    let observable = this.cartsService.updateCartItem(cartItem); /* send the new cartItem information */
    observable.subscribe(updatedPriceStatus =>{
    let chosenProduct = this.currentClickedProduct; /* setting clicked product as new var */
    let currentCartItemList = this.cartsService.cartItemsList;
    for (let index = 0; index < currentCartItemList.length; index++) {
      if (currentCartItemList[index].id == cartItem.id) {
        currentCartItemList[index].totalPrice = updatedPriceStatus.cartItemUpdatedPrice;
        currentCartItemList[index].amount = chosenProduct.amount;
        this.cartsService.cartItemsList = currentCartItemList
        let updatedTotalCartPrice = updatedPriceStatus.cartUpdatedPrice;
        this.cartsService.cartTotalPrice = updatedTotalCartPrice
      }
      
    }
    },error =>{
      /* some error action XXXXXXXXXXXXXX */
    })
    this.initProductAmount();

  }

  public addCartItemToCart(cartItem){
    let observable = this.cartsService.addNewCartItem(cartItem); /* send the new cartItem information */
    observable.subscribe(cartPriceStatus =>{
      // console.log(cartPriceStatus);
      // this.currentClickedProduct.price = cartPriceStatus.cartItemUpdatedPrice;
      let chosenProduct = this.currentClickedProduct; /* setting clicked product as new var */
      chosenProduct.totalPrice = cartPriceStatus.cartItemUpdatedPrice; /* set his total price */
      let currentCartItemList = this.cartsService.cartItemsList;
      console.log("current cart items is " + JSON.stringify(currentCartItemList))
      currentCartItemList.push(chosenProduct);
      console.log("cart items after add is : " + JSON.stringify(currentCartItemList));
      this.cartsService.cartItemsList = currentCartItemList;
      let updatedTotalCartPrice = cartPriceStatus.cartUpdatedPrice;
      this.cartsService.cartTotalPrice = updatedTotalCartPrice
    },error =>{
      /* some error action XXXXXXXX */
    })
    this.initProductAmount();
  }

}
