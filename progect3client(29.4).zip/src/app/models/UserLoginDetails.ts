export class UserLoginDetails {
    constructor(
        public email?:String,
        public password?:String
    ){}
}