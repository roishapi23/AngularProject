export class IsUserAlreadyExistsResponse {
    constructor(
        // public answer:Boolean,
        public message: String
    ){}
}