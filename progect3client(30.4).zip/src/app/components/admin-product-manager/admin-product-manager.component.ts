import { Product } from './../../models/productDetails';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-admin-product-manager',
  templateUrl: './admin-product-manager.component.html',
  styleUrls: ['./admin-product-manager.component.css']
})
export class AdminProductManagerComponent implements OnInit {
  
  public product:Product;/* product to update */
  public afterUpdateMessage:string;
  public newProduct:Product;/* product to add */
  public categorysArray = [{name:"Meat&Fish", numberId:"1"},{name:"Milk&Eggs", numberId:"2"},{name:"Vegtabels&Fruits", numberId:"3"},{name:"Wine&Drinks", numberId:"4"}]


  

  constructor(public productsService: ProductsService) {
    this.productsService = productsService;
    this.product = new Product(); 
    this.newProduct = new Product();
   }

  ngOnInit() {
    // this.product = this.productsService.adminCurrentChosenProduct;
  }

  public updateProduct(){
    this.product.id = this.productsService.adminCurrentChosenProduct.id;
    this.product.productName = this.productsService.adminCurrentChosenProduct.productName;
    this.product.price = this.productsService.adminCurrentChosenProduct.price;
    this.product.image = this.productsService.adminCurrentChosenProduct.image;
    let chosenCategory = this.productsService.adminCurrentChosenProduct.categoryId;
    let chosenCategoryId = this.getCategoryNumber(chosenCategory)
    console.log(chosenCategoryId)
    this.product.categoryId = chosenCategoryId;
    console.log("product to update is : " + JSON.stringify(this.product))
    this.sendUpdateRequest();
  }
  
  public getCategoryNumber(category){
    // let categorysArray = [{name:"Meat&Fish", numberId:"1"},{name:"Milk&Eggs", numberId:"2"},{name:"Vegtabels&Fruits", numberId:"3"},{name:"Wine&Drinks", numberId:"4"}]
    for (let index = 0; index < this.categorysArray.length; index++) {
      if (category == this.categorysArray[index].name) {
        return this.categorysArray[index].numberId;
      }
    }
  }

  public sendUpdateRequest(){
    let observable = this.productsService.updateProduct(this.product);
    observable.subscribe(updateApproval =>{
      this.productsService.updatedProssesOver = true;
      this.afterUpdateMessage = "Product has been updated"
      if (this.productsService.productCategoryBeforeUpdate != this.product.categoryId) {
        for (let index = 0; index < this.productsService.products.length; index++) {
        if (this.productsService.products[index].id == this.product.id) {
          this.productsService.products.splice(index,1)
          return;
        }
      }
    }
    },error =>{
      
      this.afterUpdateMessage = "Product update failed"

    })
  }

  public displayNewproductArea(){
    this.productsService.openedNewProductArea = true;
  }

  public addNewProduct(){
    console.log(this.newProduct)

    let observable = this.productsService.addNewProduct(this.newProduct);
    observable.subscribe(addApproval =>{
      // this.productsService.updatedProssesOver = true;
      // this.afterUpdateMessage = "Product has been updated"
      
        for (let index = 0; index < this.categorysArray.length; index++) {
        if (this.categorysArray[index].numberId == this.newProduct.categoryId) {
          this.productsService.products.push(this.newProduct);
          return;
        }
      }
    
    },error =>{

      
      // this.afterUpdateMessage = "Product update failed";

    })
    
  }
  
  

}
