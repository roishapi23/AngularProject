import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router , ParamMap } from '@angular/router';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  activatedRoute: ActivatedRoute;

  constructor(private router:Router , private route: ActivatedRoute) { }

  ngOnInit() {
  }

  public milkAndEggs(){
    
    this.router.navigate(["admin", "Milk&Eggs"]);
  }
  public vegtabelsAndFruits(){

    // location.replace("http://localhost:4200/admin/products/Vegtabels&Fruits")
    this.router.navigate(['admin/products/Vegtabels&Fruits'])
  }
  public meatAndFish(){
    
    location.replace("http://localhost:4200/admin/products/Meat&Fish")
    // this.router.navigate(['admin/products/Meat&Fish'], {relativeTo: this.activatedRoute})
  }
  public wineAndDrinks(){
    location.replace("http://localhost:4200/admin/products/Wine&Drinks")
    // this.router.navigate(['admin/products/Wine&Drinks'], {relativeTo: this.activatedRoute})
  }

}
