import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { WineAndDrinksComponent } from './components/products/wine-and-drinks/wine-and-drinks.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { MeatAndFishComponent } from './components/products/meat-and-fish/meat-and-fish.component';
import { VegtabelsAndFruitsComponent } from './components/products/vegtabels-and-fruits/vegtabels-and-fruits.component';
import { MilkAndEggsComponent } from './components/products/milk-and-eggs/milk-and-eggs.component';
import { ShopComponent } from './components/shop/shop.component';


// const routes: Routes = [
//     { 
//         // path: "shop", component: ShopComponent, children:[
//             // { path: "Milk&Eggs", component: MilkAndEggsComponent },
//             { path: "Vegtabels&Fruits", component: VegtabelsAndFruitsComponent },
//             { path: "Meat&Fish", component: MeatAndFishComponent },
//             { path: "Wine&Drinks", component: WineAndDrinksComponent },
//             { path: "", redirectTo: "milk&eggs", pathMatch: "full" }
//         ]
//     }
// ];

@NgModule({
    declarations: [ 
        // ShopComponent,
        //  MilkAndEggsComponent,
        //   VegtabelsAndFruitsComponent,
        //    MeatAndFishComponent , 
        //    WineAndDrinksComponent
    ],
    imports: [
      CommonModule,
    //   RouterModule.forChild(routes) // Importing the above routes
  ]
})
export class MainAreaModule {

}
