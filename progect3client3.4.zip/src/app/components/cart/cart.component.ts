import { UsersService } from './../../services/users.service';
import { Component, OnInit } from '@angular/core';
import { CartsService } from 'src/app/services/carts.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public cartItems = [];

  constructor(public cartsService:CartsService , public usersService:UsersService) {
    
   }

  ngOnInit() {
    // this.cartItems = [
    //   {name: "yossi", amount: 5 , price: 54},
    //   {name: "danielii", amount: 1 , price: 97}
    // ]
     let userId = this.usersService.userId;
    console.log("id in user service is: "+userId)
    if (userId == undefined) {
      let userDetails = JSON.parse(sessionStorage.getItem("userDetails"))
      userId = userDetails.id
    }
    // let observable = this.cartsService.setNewCart({id: userId});
    // observable.subscribe(serverResponse => {
    //   // alert(serverResponse)
    // }, error => {

    // })
  }

  // public deleteCartItem(){
  //   this.cartItems.splice()
  // }

}
