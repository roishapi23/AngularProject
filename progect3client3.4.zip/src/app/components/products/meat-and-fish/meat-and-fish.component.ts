import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';
import { Product } from 'src/app/models/productDetails';

@Component({
  selector: 'app-meat-and-fish',
  templateUrl: './meat-and-fish.component.html',
  styleUrls: ['./meat-and-fish.component.css']
})
export class MeatAndFishComponent implements OnInit {

  public product : Product[];
  private categoryId : Number;
  public products : Product[];

  constructor(private productsService : ProductsService) {
    this.categoryId = 1;
   }

  ngOnInit() {
    let observable = this.productsService.getProductsbyCategory(this.categoryId);
    observable.subscribe(meatAndFishProducts =>{
      console.log(meatAndFishProducts)
      this.products = meatAndFishProducts;
      
    },error =>{

    })
  }

}
