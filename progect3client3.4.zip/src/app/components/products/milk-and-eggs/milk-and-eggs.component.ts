import { ProductsService } from './../../../services/products.service';
import { Product } from './../../../models/productDetails';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-milk-and-eggs',
  templateUrl: './milk-and-eggs.component.html',
  styleUrls: ['./milk-and-eggs.component.css']
})
export class MilkAndEggsComponent implements OnInit {

  public products : Product[];
  private categoryId : Number;
  public clickedProduct: Product;

  constructor(private productsService : ProductsService) {
    this.categoryId = 2;
    this.clickedProduct = {productName:"" , price: 0, image:""}
  }
  
  ngOnInit() {
    let observable = this.productsService.getProductsbyCategory(this.categoryId);
    observable.subscribe(milkAndEggsProducts =>{
      console.log(milkAndEggsProducts);
      this.products = milkAndEggsProducts;
      this.clickedProduct = milkAndEggsProducts[0];
    },error =>{

    })

  }

  public showCoupons(){
    alert("workss")
  }
  public setClickedProduct(clickedProduct){
    this.clickedProduct = clickedProduct;
  }

}
