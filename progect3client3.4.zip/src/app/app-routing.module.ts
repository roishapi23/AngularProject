import { AdminComponent } from './components/admin/admin.component';
import { CustomerComponent } from './components/customer/customer.component';
import { MilkAndEggsComponent } from './components/products/milk-and-eggs/milk-and-eggs.component';


import { MainComponent } from './components/main/main.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { MenuComponent } from './components/menu/menu.component';
import { RegisterComponent } from './components/register/register.component';
import { CommonModule } from '@angular/common';
import { from } from 'rxjs';
import { ShopComponent } from './components/shop/shop.component';
import { VegtabelsAndFruitsComponent } from './components/products/vegtabels-and-fruits/vegtabels-and-fruits.component';
import { MeatAndFishComponent } from './components/products/meat-and-fish/meat-and-fish.component';
import { WineAndDrinksComponent } from './components/products/wine-and-drinks/wine-and-drinks.component';


const routes: Routes = [
    { 
        path: "home", component: MainComponent, children:[
            { path: "login", component: LoginComponent },
            { path: "customer", component: CustomerComponent },
            { path: "register", component: RegisterComponent },
            { path: "", redirectTo: "login", pathMatch: "full" }
          ]
        },
  {path: "" , redirectTo: "home" , pathMatch: "full"},
        
  { path: "admin", component: AdminComponent },
  { 
        path: "shop", component: ShopComponent, children:[
            // { path: "allProducts", component: AllProductsComponent },
            { path: "Milk&Eggs", component: MilkAndEggsComponent },
            { path: "Vegtabels&Fruits", component: VegtabelsAndFruitsComponent },
            { path: "Meat&Fish", component: MeatAndFishComponent },
            { path: "Wine&Drinks", component: WineAndDrinksComponent },
            { path: "", redirectTo: "shop", pathMatch: "full" }
        ]
      },
];

@NgModule({
  declarations: [],
    imports: [
      CommonModule,
      RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }
