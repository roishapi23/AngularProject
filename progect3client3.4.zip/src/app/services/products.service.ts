import { AmountStatusFirstUI } from './../models/AmountInfoFirstUI';
import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { Observable } from 'rxjs';
import { Product } from '../models/productDetails';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http: HttpClient) { }

  public getProductsbyCategory(id):Observable<Product[]> {
    return this.http.get<Product[]>("/api/products/byCategory/"+id)
  }
  public getFirstUIAmountInfo():Observable<AmountStatusFirstUI> {
    return this.http.get<AmountStatusFirstUI>("/api/products/amount")
  }
}
