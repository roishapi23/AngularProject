import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserCartsStatus } from '../models/userCartsStatus';

@Injectable({
  providedIn: 'root'
})
export class CartsService {

  public userFirstTime = false;
  public userHasOpenCart = false;
  public userHasOldCart = false;
  public openCart;

  constructor(private http: HttpClient) { }

  public getUserCartsStatus(userId : Number):Observable<UserCartsStatus> {
    return this.http.get<UserCartsStatus>("/api/carts/status/"+userId)
  }
  public setNewCart(userId : Object):Observable<Object> {
    return this.http.post<Object>("/api/carts" , userId)
  }
}
