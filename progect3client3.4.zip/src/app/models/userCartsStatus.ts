export class UserCartsStatus {
    constructor(
        public status:String,
        public lastCartDate?:any,
        public cart?:Object
    ){}
}