export class Product {
    constructor(
        public productName:String,
        public price:Number,
        public image:String
    ){}
}