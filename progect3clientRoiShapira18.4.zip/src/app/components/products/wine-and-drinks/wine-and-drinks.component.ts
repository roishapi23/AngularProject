import { ProductsService } from './../../../services/products.service';
import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/productDetails';

@Component({
  selector: 'app-wine-and-drinks',
  templateUrl: './wine-and-drinks.component.html',
  styleUrls: ['./wine-and-drinks.component.css']
})
export class WineAndDrinksComponent implements OnInit {

  public products : Product[];
  private categoryId : Number;

  constructor(private productsService : ProductsService) {
    this.categoryId = 4;
   }

  ngOnInit() {
    let observable = this.productsService.getProductsbyCategory(this.categoryId);
    observable.subscribe(wineAndDrinks =>{
      // console.log(wineAndDrinks);
    this.products = wineAndDrinks
      
    },error =>{

    })
  }

}
