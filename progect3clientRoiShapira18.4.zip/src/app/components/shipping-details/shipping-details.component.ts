import { PurchasesService } from './../../services/purchases.service';
import { ShippingDetails } from './../../models/ShippingDetails';
import { Component, OnInit } from '@angular/core';
import { CartsService } from 'src/app/services/carts.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as jsPDF from 'jspdf'; 
import 'jspdf-autotable';

@Component({
  selector: 'app-shipping-details',
  templateUrl: './shipping-details.component.html',
  styleUrls: ['./shipping-details.component.css']
})
export class ShippingDetailsComponent implements OnInit {
  public customerShippingDetails: ShippingDetails;
  public userDetails:Object;
  public isDateAvailable = true;
  // public purchaseCompleted = false;
  public resarvationNumber = 0;
  activatedRoute: ActivatedRoute;
  /* make the user not possible to choose past dates */
  minDate = moment(new Date()).format('YYYY-MM-DD'); 

  public pdfItems = [];
  public footer ;
  

  constructor(public purchaseService:PurchasesService , public cartsService:CartsService , private router:Router , private route: ActivatedRoute) {
    this.customerShippingDetails = new ShippingDetails();
   }

  ngOnInit() {
    this.customerShippingDetails.cartId = this.cartsService.userCartId;
    
  }

  public pay(){
    this.isDateAvailable = true;
    console.log(this.customerShippingDetails);
    let observable = this.purchaseService.setThePurchase(this.customerShippingDetails)
    observable.subscribe(purchaseResponse =>{
      console.log(purchaseResponse)
      if (purchaseResponse.dateAvilabilityStatus == false) {
        this.isDateAvailable = false;
        return;
      }
      this.purchaseService.isPurchaseCompleted = true;

      this.resarvationNumber = purchaseResponse.resarvationNumber
      
      

    }, error => {
      // some error action
    })
  }
  public fillDetails(){
    // let userDetails = JSON.parse(sessionStorage.getItem("userDetails"));
    let observable = this.purchaseService.getCustomerShippingAddress();
    observable.subscribe(customerAddress =>{
      
      console.log(customerAddress.city)
      console.log(customerAddress.street)
      this.customerShippingDetails.city = customerAddress.city;
      this.customerShippingDetails.street = customerAddress.street;

    }, error => {
      // some error action
    })
  }

  public navToHomePage(){
    sessionStorage.setItem("Cart ID", JSON.stringify(0));
    this.cartsService.cartItemsList = [];
    this.cartsService.cartTotalPrice = 0;
    this.router.navigate(['home/customer'], {relativeTo: this.activatedRoute})
  }



   // -------------------------------------------
  head = [['no.', 'Item', 'Amount', 'Price']]
 
  // data = [
  //   [1, 'Finland', 7.632, 'Helsinki'],
  //   [2, 'Norway', 7.594, 'Oslo'],
  //   [3, 'Denmark', 7.555, 'Copenhagen'],
  //   [4, 'Iceland', 7.495, 'Reykjavík'],
  //   [5, 'Switzerland', 7.487, 'Bern'],
  //   [9, 'Sweden', 7.314, 'Stockholm'],
  //   [73, 'Belarus', 5.483, 'Minsk'],
  // ]

  data = this.pdfItems;

  
  public createPdf() {
    this.setCartItemsForPDF()
    var doc = new jsPDF();
 
    doc.setFontSize(18);
    doc.text('Purchase details - resarvation Number: '+this.resarvationNumber , 11, 8);
    doc.setFontSize(11);
    doc.setTextColor(100);
 
 
    (doc as any).autoTable({
      head: this.head,
      body: this.data,
      foot: this.footer,
      theme: 'grid',
      didDrawCell: data => {
        console.log(data.column.index)
      }
    })
 
    // Open PDF document in new tab
    // doc.output('dataurlnewwindow')
 
    // Download PDF document  
    doc.save('CartRecipt.pdf');
    this.pdfItems = [];
  }

  public setCartItemsForPDF(){
    let counter = 1;
    for (let index = 0; index < this.cartsService.cartItemsList.length; index++) {
      let item = [counter , this.cartsService.cartItemsList[index].productName , this.cartsService.cartItemsList[index].amount , "ILS "+this.cartsService.cartItemsList[index].totalPrice]
      this.pdfItems.push(item);
      counter++
    }
    this.footer = [["","Total price:" , "ILS "+ this.cartsService.cartTotalPrice,"" ]]
    // let lastRow = ["Total price" , "" , "" , "ILS "+this.cartsService.cartTotalPrice];
    // this.pdfItems.push(lastRow);
  }

 

}
