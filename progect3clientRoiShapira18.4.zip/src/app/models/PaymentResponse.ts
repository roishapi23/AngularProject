export class PaymentResponse {
    constructor(
        public dateAvilabilityStatus?:boolean,
        public paidPrice?:number,
        public resarvationNumber?:number
    ){}
}