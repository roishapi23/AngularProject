import { CartsService } from './../../services/carts.service';
import { UsersService } from './../../services/users.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  activatedRoute: ActivatedRoute;
  public cartDate;

  constructor(public usersService:UsersService , public cartsService:CartsService , private router:Router , private route: ActivatedRoute) { 
    // this.usersService = usersService;
    // this.customerName = customerName;
  }

  ngOnInit() {

    this.initCartsServiceElements()

    if (this.usersService.customerName == undefined) {
      let userDetails = JSON.parse(sessionStorage.getItem("userDetails"))
      this.usersService.customerName = userDetails.name
    }
    let userId = this.usersService.userId;
    console.log("id in service is: "+userId)
    if (userId == undefined) {
      let userDetails = JSON.parse(sessionStorage.getItem("userDetails"))
      userId = userDetails.id
    }
    console.log("id cefore request is: "+userId)
    let observable = this.cartsService.getUserCartsStatus(userId);
    observable.subscribe(userCartsStatus =>{
      console.log("all data server" + JSON.stringify(userCartsStatus))
      console.log("data ftom server "+userCartsStatus.status)
      if (userCartsStatus.status == "NEW USER" ) {
        this.cartsService.userFirstTime = true
        return;
      }
        console.log("last date of purchase ftom server "+userCartsStatus.lastCartDate)
        let serverExactCartDate = JSON.stringify(userCartsStatus.lastCartDate).slice(1,11);
        if (userCartsStatus.status == "OPEN CART"){ 
          // this.cartsService.userHasOldCart = false;
          this.cartsService.userHasOpenCart = true;
          this.cartDate = serverExactCartDate;
          sessionStorage.setItem("Cart ID" , JSON.stringify(userCartsStatus.cartId));
          // this.cartsService.userCartId = userCartsStatus.cartId
          return
        }
        if (userCartsStatus.status == "OLD USER") {
          // this.cartsService.userHasOpenCart = false;
          this.cartsService.userHasOldCart = true
          this.cartDate = serverExactCartDate;
          return
        }
      
    
    },error => {

    })

  }

  public navigateToShop(){
    this.router.navigate(['shop'], {relativeTo: this.activatedRoute})
  }
  public initCartsServiceElements(){
    this.cartsService.userHasOldCart = false;
    this.cartsService.userHasOpenCart = false;
    this.cartsService.userFirstTime = false;
  }


}
