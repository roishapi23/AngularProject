import { ProductsService } from './services/products.service';
import { CartsService } from 'src/app/services/carts.service';



import { UsersService } from './services/users.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { LayoutComponent } from './components/layout/layout.component';
import { HeaderComponent } from './components/header/header.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { FirstSiteStatusComponent } from './components/first-site-status/first-site-status.component';
import { MenuComponent } from './components/menu/menu.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ShopComponent } from './components/shop/shop.component';
import { VegtabelsAndFruitsComponent } from './components/products/vegtabels-and-fruits/vegtabels-and-fruits.component';
import { MeatAndFishComponent } from './components/products/meat-and-fish/meat-and-fish.component';
import { WineAndDrinksComponent } from './components/products/wine-and-drinks/wine-and-drinks.component';
import { MainComponent } from './components/main/main.component';
import { MilkAndEggsComponent } from './components/products/milk-and-eggs/milk-and-eggs.component';
import { CustomerComponent } from './components/customer/customer.component';
import { CartComponent } from './components/cart/cart.component';
import { AdminComponent } from './components/admin/admin.component';


@NgModule({
  declarations: [
    LayoutComponent,
    HeaderComponent,
    WelcomeComponent,
    FirstSiteStatusComponent,
    MenuComponent,
    RegisterComponent,
    LoginComponent,
    MainComponent,
    MilkAndEggsComponent,
    ShopComponent,
    VegtabelsAndFruitsComponent,
    MeatAndFishComponent , 
    WineAndDrinksComponent,
    CustomerComponent,
    CartComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    // MainAreaModule

  ],
  providers: [UsersService , CartsService , ProductsService],
  bootstrap: [LayoutComponent]
})
export class AppModule { }
