import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {
  activatedRoute: ActivatedRoute;

  constructor(private router:Router , private route: ActivatedRoute) { }

  ngOnInit() {
  }

  public milkAndEggs(){
    this.router.navigate(['shop/Milk&Eggs'], {relativeTo: this.activatedRoute})
  }
  public vegtabelsAndFruits(){
    this.router.navigate(['shop/Vegtabels&Fruits'], {relativeTo: this.activatedRoute})
  }
  public meatAndFish(){
    this.router.navigate(['shop/Meat&Fish'], {relativeTo: this.activatedRoute})
  }
  public wineAndDrinks(){
    this.router.navigate(['shop/Wine&Drinks'], {relativeTo: this.activatedRoute})
  }

}
