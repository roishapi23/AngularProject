export class SuccessfullLoginServerResponse {
    constructor(
        public id:Number,
        public token:String,
        public userType:String,
        public name:String
    ){}
}