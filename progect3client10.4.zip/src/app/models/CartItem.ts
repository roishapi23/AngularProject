export class CartItem {
    constructor(
        public amount?:number,
        public productId?:Number,
        public cartId?:Number
        
    ){}
}